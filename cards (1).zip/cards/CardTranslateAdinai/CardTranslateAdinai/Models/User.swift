//
//  User.swift
//  snackstore1
//
//  Created by marzhan on 21/11/24.
//

import Foundation
struct User: Codable{
    let id: String
    let name: String
    let email: String
    let joined: TimeInterval
}
