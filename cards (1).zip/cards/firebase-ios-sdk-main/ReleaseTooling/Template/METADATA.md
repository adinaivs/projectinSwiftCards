## Dependency Graph

"(~> X)" below means that the SDK requires all of the xcframeworks from X. You
should make sure to include all of the xcframeworks from X when including the
SDK.

__INTEGRATION__

## Versions

The xcframeworks in this directory map to these versions of the Firebase SDKs in
CocoaPods.

__VERSIONS__
