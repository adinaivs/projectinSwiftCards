# 8.11.0
- Introduced shared Codable implementation. Initially used by Firebase Functions
  and Firebase Database. (#9091)
