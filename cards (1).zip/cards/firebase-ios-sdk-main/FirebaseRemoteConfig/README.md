# Firebase Remote Config SDK for iOS

This pod contains the Firebase Remote Config SDK for iOS, supporting both
Objective-C and Swift.

Firebase Remote Config is a cloud service that lets you change the appearance
and behavior of your app without requiring users to download an app update.

Please visit [our developer site](https://firebase.google.com/docs/remote-config/)
for integration instructions, documentation, support information, and terms of service.
