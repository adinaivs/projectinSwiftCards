# 10.8.0
- [fixed] Use caller's encoder when setting document data (#11033).

# 8.9.0
- [feature] Added Combine support for Cloud Functions for Firebase
- [feature] Added Combine support for Firebase Auth
- [feature] Added Combine support for Firebase Storage
- [feature] Added Combine support for Cloud Firestore
