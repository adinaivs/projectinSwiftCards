Firebase Sessions does not keep a changelog since it's only an
independent module for code-sharing purposes.
